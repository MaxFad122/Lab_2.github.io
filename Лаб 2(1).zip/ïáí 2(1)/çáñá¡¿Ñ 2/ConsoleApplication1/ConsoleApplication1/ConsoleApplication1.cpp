﻿#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <limits>


void replaceMinWithSum(std::vector<std::vector<double>>& matrix, int rows, int cols)
{
    for (int j = 0; j < cols; ++j) {
        double minElement = std::numeric_limits<double>::max();
        double sumPositive = 0.0;
        int minRow = -1;


        for (int i = 0; i < rows; ++i) {
            if (matrix[i][j] < minElement) {
                minElement = matrix[i][j];
                minRow = i;
            }

            if (matrix[i][j] > 0)
                sumPositive += matrix[i][j];
        }


        if (minRow != -1)
            matrix[minRow][j] = sumPositive;


        std::cout << "Minimum number in the column" << j << ": " << minElement << ", Coordinates: (" << minRow << ", " << j << ")\n";
    }
}


bool hasAlternatingSigns(const std::vector<double>& row)
{
    if (row.size() < 2)
        return false;

    bool positive = row[0] > 0;
    for (size_t i = 1; i < row.size(); ++i) {
        if ((row[i] > 0 && positive) || (row[i] < 0 && !positive))
            return false;

        positive = !positive;
    }

    return true;
}

int main()
{
    setlocale(LC_ALL, "Russian");
    int k, m;
    std::cout << "Enter the number of rows (k): ";
    std::cin >> k;
    std::cout << "Enter the number of columns (m): ";
    std::cin >> m;


    std::vector<std::vector<double>> matrix(k, std::vector<double>(m));


    std::srand(std::time(0));
    for (int i = 0; i < k; ++i) {
        for (int j = 0; j < m; ++j) {
            matrix[i][j] = static_cast<double>(std::rand()) / RAND_MAX * 2 - 1; // Generating numbers от -1 до 1
        }
    }


    std::cout << "The formed matrix:\n";
    for (int i = 0; i < k; ++i) {
        for (int j = 0; j < m; ++j) {
            std::cout << matrix[i][j] << " ";
        }
        std::cout << "\n";
    }


    replaceMinWithSum(matrix, k, m);


    std::vector<int> D;
    for (int i = 0; i < k; ++i) {
        if (hasAlternatingSigns(matrix[i]))
            D.push_back(i);
    }


    std::cout << "Modified matrix:\n";
    for (int i = 0; i < k; ++i) {
        for (int j = 0; j < m; ++j) {
            std::cout << matrix[i][j] << " ";
        }
        std::cout << "\n";
    }


    if (D.empty()) {
        std::cout << "There are no alternating lines\n";
    }
    else {
        std::cout << "Vector D of line numbers with alternating\n";
        for (size_t i = 0; i < D.size(); ++i) {
            std::cout << D[i] << " ";
        }
        std::cout << "\n";
    }

    return 0;
}
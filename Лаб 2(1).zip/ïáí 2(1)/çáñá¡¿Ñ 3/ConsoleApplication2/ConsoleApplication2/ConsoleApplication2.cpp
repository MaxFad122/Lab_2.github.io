﻿#include <iostream>
#include <vector>
#include <cmath>


std::vector<double> solveLinearEquations(const std::vector<std::vector<double>>& A, const std::vector<double>& b) {
    int n = A.size();
    std::vector<std::vector<double>> augmentedMatrix(n, std::vector<double>(n + 1));


    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            augmentedMatrix[i][j] = A[i][j];
        }
        augmentedMatrix[i][n] = b[i];
    }


    for (int i = 0; i < n; ++i) {
        int pivotRow = i;
        for (int j = i + 1; j < n; ++j) {
            if (std::abs(augmentedMatrix[j][i]) > std::abs(augmentedMatrix[pivotRow][i])) {
                pivotRow = j;
            }
        }
        std::swap(augmentedMatrix[i], augmentedMatrix[pivotRow]);

        for (int j = i + 1; j <= n; ++j) {
            augmentedMatrix[i][j] /= augmentedMatrix[i][i];
        }
        augmentedMatrix[i][i] = 1;

        for (int j = i + 1; j < n; ++j) {
            for (int k = i + 1; k <= n; ++k) {
                augmentedMatrix[j][k] -= augmentedMatrix[j][i] * augmentedMatrix[i][k];
            }
            augmentedMatrix[j][i] = 0;
        }
    }


    std::vector<double> solution(n);
    for (int i = n - 1; i >= 0; --i) {
        solution[i] = augmentedMatrix[i][n];
        for (int j = i + 1; j < n; ++j) {
            solution[i] -= augmentedMatrix[i][j] * solution[j];
        }
    }

    return solution;
}

int main() {
    setlocale(LC_ALL, "Russian");
    std::vector<std::vector<double>> A = { {0.34, 0.71, 0.63},
                                          {0.71, -0.65, -0.18},
                                          {1.17, -2.35, 0.75} };
    std::vector<double> b = { 2.08, 0.17, 1.28 };

    std::vector<double> X = solveLinearEquations(A, b);


    std::vector<double> vectorResult(3);
    for (int i = 0; i < 3; ++i) {
        vectorResult[i] = 2 * X[i] - 3;
    }


    double modulus = 0.0;
    for (int i = 0; i < 3; ++i) {
        modulus += std::abs(vectorResult[i]) * std::abs(vectorResult[i]);
    }
    modulus = std::sqrt(modulus);

    std::cout << "СLAY Solution: ";
    for (const auto& value : X) {
        std::cout << value << " ";
    }
    std::cout << std::endl;

    std::cout << "Vector modulus |2X-3|: " << modulus << std::endl;

    return 0;
}
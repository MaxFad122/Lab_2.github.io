﻿#include <iostream>
#include <random>

const int MAX_VALUE = 100;

int countDigits(int num) {
    int count = 0;
    while (num != 0) {
        num /= 10;
        count++;
    }
    return count;
}

bool isDecreasingSequence(int num) {
    int count = countDigits(num);
    if (count <= 1) {
        return false;
    }

    int prevDigit = num % 10;
    num /= 10;

    while (num != 0) {
        int currDigit = num % 10;
        if (currDigit <= prevDigit) {
            return false;
        }
        prevDigit = currDigit;
        num /= 10;
    }

    return true;
}

void calculateB(int** A, int n) {

    int** B = new int* [n];
    for (int i = 0; i < n; i++) {
        B[i] = new int[n];
        for (int j = 0; j < n; j++) {
            B[i][j] = 0;
            for (int k = 0; k < n; k++) {
                B[i][j] += (A[i][k] * A[k][j]) / 5;
            }
        }
    }


    std::cout << "Matrix B (expression value B = 1/5*A^2):\n" << std::endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            std::cout << B[i][j] << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;


    for (int i = 0; i < n; i++) {
        delete[] B[i];
    }
    delete[] B;
}

int main() {
    setlocale(LC_ALL, "Russian");
    int n;
    std::cout << "Enter the dimension of the array:";
    std::cin >> n;


    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dis(0, MAX_VALUE);


    int** A = new int* [n];
    for (int i = 0; i < n; i++) {
        A[i] = new int[n];
        for (int j = 0; j < n; j++) {
            A[i][j] = dis(gen);
        }
    }


    std::cout << "Matrix A:" << std::endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            std::cout << A[i][j] << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;


    int minRowIndex = 0;
    int minColIndex = 0;
    int minValue = A[0][0];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (A[i][j] < minValue) {
                minValue = A[i][j];
                minRowIndex = i;
                minColIndex = j;
            }
        }
    }


    int oddCount = 0;
    int oddSum = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (A[i][j] % 2 != 0) {
                oddCount++;
                oddSum += A[i][j];
            }
        }
    }

    double oddAverage = static_cast<double>(oddSum) / oddCount;


    int decreasingCount = 0;

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (A[i][j] > 0 && isDecreasingSequence(A[i][j])) {
                decreasingCount++;
            }
        }
    }


    std::cout << "Indexes of the smallest element: (" << minRowIndex << ", " << minColIndex << ")" << std::endl;
    std::cout << "Arithmetic mean of odd numbers: " << oddAverage << std::endl;
    std::cout << "The number of positive elements representing a decreasing sequence of digits: " << decreasingCount << std::endl;


    calculateB(A, n);


    for (int i = 0; i < n; i++) {
        delete[] A[i];
    }
    delete[] A;

    return 0;
}